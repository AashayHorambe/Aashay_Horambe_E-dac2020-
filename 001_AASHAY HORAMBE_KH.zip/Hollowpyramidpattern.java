import java.util.Scanner;
class Hollowpyramidpattern
{
 public static void main(String[] args)
 {
Scanner sc=new Scanner(System.in);
System.out.println("Enter value of N:");
int N=sc.nextInt();
for(int i=1;i<=N;i++)
	{
	for(int j=N-1;j>=i;j--)
             {
	System.out.print(" ");
             }
        for(int k=1;k<=2*i-1;k++)
            
        {
            if(k==1 || k==(2*i-1) || (k%2==1 && i==N))
            {
                System.out.print("*");
            }
            else
            {
                System.out.print(" ");
            }
        }
        System.out.println();
             }
      
}
}
