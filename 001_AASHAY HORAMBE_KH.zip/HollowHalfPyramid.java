import java.util.Scanner;
class HollowHalfPyramid
{
 public static void main(String[] args)
 {
Scanner sc=new Scanner(System.in);
System.out.println("Enter value of N:");
int N=sc.nextInt();

for(int i=N;i>=1;i--)
	{
            for(int j=i;j>=1;j--)
             if((j==i)|| (i==6))
              {
	System.out.print("*");
            }
            for(int j=i;j>=2;j--)
            if(j==2 && i!=N)
              {
	System.out.print("*");
            }
            else
            {
                System.out.print(" ");
            }
            
   
        System.out.println();
             }
      
}
}
