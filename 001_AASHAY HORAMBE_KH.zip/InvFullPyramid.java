 import java.util.Scanner;
class InvFullPyramid
{
 public static void main(String[] args)
 {
Scanner sc=new Scanner(System.in);
System.out.println("Enter value of N:");
int N=sc.nextInt();
for(int i=N;i>=1;i--)
	{
	for(int j=N-1;j>=i;j--)
             {
	System.out.print("  ");
             }
            for(int k=1;k<=i;k++)
             {
	System.out.print(" *  ");
             }
        System.out.println();
             }
      
}
}
