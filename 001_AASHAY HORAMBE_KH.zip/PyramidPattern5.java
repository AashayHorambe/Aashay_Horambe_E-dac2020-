
import java.util.Scanner;
class PyramidPattern5
{
 public static void main(String[] args)
 {
Scanner sc=new Scanner(System.in);
System.out.println("Enter value of N:");
int N=sc.nextInt();
for(int i=N;i>=1;i--)
	{
	for(int j=i-1;j>=1;j--)
             {
	System.out.print("  ");
             }
            for(int k=i;k<=N;k++)
             {
	System.out.print(k+" ");
             }
            for(int m=N-1;m>=i;m--)
             {
	System.out.print(m+" ");
             }
        System.out.println();
             }
      
}
}
