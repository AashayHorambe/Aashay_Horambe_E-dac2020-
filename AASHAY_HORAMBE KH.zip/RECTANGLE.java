import java.util.Scanner;
public class RECTANGLE
 {

    public static void main(String[] args)
   {
        
        float W,H,Z,Area,Per;
        System.out.println("Enter width of rectangle: ");
        Scanner sc1 = new Scanner(System.in);
        W=sc1.nextFloat();
        Scanner sc2 = new Scanner(System.in);
        System.out.println("Enter height of rectangle: ");
        H=sc2.nextFloat(); 
        Area=W * H;
        System.out.println("Area of rectangle is: "+Area);
        Per=2 *(W + H);
        System.out.println("Perimeter of rectangle is: "+Per);
    }
}
