import java.util.Scanner;
public class BinToDec
{
 public static void main(String[] args) 
 {
  long X, Y= 0, j = 1, rem;
  System.out.println("Input a binary number");
  Scanner sc = new Scanner(System.in);
  X= sc.nextLong();
  while (X != 0) 
  {
   rem= X % 10;
   Y = Y + rem * j;
   j = j * 2;
   X = X / 10;
  }
  System.out.println("Decimal Number: " + Y);
 }
}