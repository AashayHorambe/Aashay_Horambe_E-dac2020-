import java.util.Scanner;
public class MULBIN {
 public static void main(String[] args)
 {
  long B1, B2;
  int i = 0, rem = 0;
  int[] mul = new int[20];
  Scanner sc = new Scanner(System.in);

  System.out.print("first binary number: ");
  B1 = sc.nextLong();
  System.out.print("second binary number: ");
  B2 = sc.nextLong();

  while (B1 != 0 || B2 != 0) 
  {
   mul[i] = (int)((B1 % 10 * B2 % 10 + rem) % 2);
   rem = (int)((B1 % 10 + B2 % 10 + rem) / 2);
   B1 = B1 / 10;
   B2 = B2 / 10;
   i++;
  }
  if (rem != 0) {
   mul[i++] = rem;
  }
  --i;
  System.out.print("multiplication of two binary numbers: ");
  while (i >= 0)
  {
   System.out.print(mul[i--]);
  }
   System.out.println();  
 }
}