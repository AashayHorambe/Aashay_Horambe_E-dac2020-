import java.util.Scanner;
public class DecimalToHex
{
   public static void main(String args[])
   {
     int rem; 
     String S=""; 
     char hex[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
     Scanner input = new Scanner( System.in );
     System.out.println("Enter a decimal number : ");
     int X=input.nextInt();
     while(X>0)
     {
       rem=X%16; 
       S=hex[rem]+S; 
       X=X/16;
     }
     System.out.println(" Decimal to hexadecimal: "+S);
  }
}