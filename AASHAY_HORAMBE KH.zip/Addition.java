import java.util.Scanner;
public class Addition
 {

    public static void main(String[] args)
   {
        
        int X,Y,Z ;
        System.out.println("Enter Two Number: ");
        Scanner sc1 = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);
        X=sc1.nextInt();
        Y=sc2.nextInt();  
        Z=X+Y;
        System.out.println("Sum of two numbers are: "+Z);
    }
}
