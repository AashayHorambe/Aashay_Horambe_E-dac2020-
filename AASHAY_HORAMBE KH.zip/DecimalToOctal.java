import java.util.Scanner;
public class DecimalToOctal
{
   public static void main(String args[])
   {
     int rem; 
     String S=""; 
     char octal[]={'0','1','2','3','4','5','6','7'};
     Scanner input = new Scanner( System.in );
     System.out.println("Enter a decimal number : ");
     int X=input.nextInt();
     while(X>0)
     {
       rem=X%8; 
       S=octal[rem]+S; 
       X=X/8;
     }
     System.out.println(" Decimal to octal: "+S);
  }
}