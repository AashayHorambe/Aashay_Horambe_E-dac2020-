import java.util.Scanner;
public class P[RODUCT
 {

    public static void main(String[] args)
   {
        
        int X,Y,Z ;
        System.out.println("Input first number: ");
        Scanner sc1 = new Scanner(System.in);
        X=sc1.nextInt();
        System.out.println("Input second number: ");
        Scanner sc2 = new Scanner(System.in);
        Y=sc2.nextInt();  
        Z=X*Y;
        System.out.println("Product of two numbers are: "+Z);
    }
}
