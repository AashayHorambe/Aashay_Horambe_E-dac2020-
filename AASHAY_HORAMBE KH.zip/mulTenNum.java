import java.util.Scanner;
public class mulTenNum
 {

    public static void main(String[] args)
   {
        
        int X,i=1,Sum;
        System.out.println("Input number: ");
        Scanner sc1 = new Scanner(System.in);
        X=sc1.nextInt();
       while(i<=10)
       {
       Sum=X*i;
       i++;
       System.out.println("Multiplication is"+Sum);
       }
    }
}
