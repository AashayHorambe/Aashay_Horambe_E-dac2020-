import java.util.Scanner;

public class BinToHex
{
 public static void main(String args[])
 {
  int b;
  int rem ,rem1,j=1,Y=0;
  String h="";
        
   char hex[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
   Scanner scan = new Scanner(System.in);
		
   System.out.print("Enter Binary Number : ");
   b = scan.nextInt();
	 
	while (b != 0) 
   {
   rem1= b % 10;
   Y = Y + rem1 * j;
   j = j * 2;
   b = b / 10;
   }	
   while(Y>0)
   {
   rem = Y%16;
    h = hex[rem] + h;
     Y= Y/16;
   }
		
   System.out.println("Hexadecimal Value ");
   System.out.print(h);
 }
}