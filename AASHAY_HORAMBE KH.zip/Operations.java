import java.util.Scanner;
public class Operations
 {

    public static void main(String[] args)
   {
        
        int X,Y,S,M,Sub,D,R;
        System.out.println("Input first number: ");
        Scanner sc1 = new Scanner(System.in);
        X=sc1.nextInt();
        System.out.println("Input second number: ");
        Scanner sc2 = new Scanner(System.in);
        Y=sc2.nextInt();  
        S=X+Y;
        M=X*Y;
        Sub=X-Y;
        D=X/Y;
        R=X% Y; 
        System.out.println("SUM=: "+S);
        System.out.println("MULTIPLICATION=: "+M);
        System.out.println("SUBSTRACTION=: "+Sub);
        System.out.println("DIVISION: "+D);
        System.out.println("REMINDER=: "+R);
    }
}
