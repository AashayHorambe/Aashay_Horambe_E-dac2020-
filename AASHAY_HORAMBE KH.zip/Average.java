import java.util.Scanner;
public class Average
 {

    public static void main(String[] args)
   {
        
        float X,Y,Z,Avg;
        System.out.println("Enter Three Numbers: ");
        Scanner sc1 = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);
        Scanner sc3 = new Scanner(System.in);
        X=sc1.nextInt();
        Y=sc2.nextInt();  
        Z=sc3.nextInt();
        Avg=(X+Y+Z)/3;
        System.out.println("Average of three numbers are: "+Avg);
    }
}
