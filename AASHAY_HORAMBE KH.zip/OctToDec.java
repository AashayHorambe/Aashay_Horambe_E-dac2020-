import java.util.Scanner;
public class OctToDec
{
 public static void main(String[] args) 
 {
  int X, Y= 0, j = 1, rem;
  System.out.println("Input a octal number");
  Scanner sc = new Scanner(System.in);
  X= sc.nextInt();
  while (X != 0) 
  {
   rem= X % 10;
   Y = Y + rem * j;
   j = j * 8;
   X = X / 10;
  }
  System.out.println("Decimal Number: " + Y);
 }
}