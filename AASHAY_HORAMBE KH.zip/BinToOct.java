import java.util.Scanner;

public class BinToOct
{
 public static void main(String args[])
 {
  int b;
  int rem ,rem1,j=1,Y=0;
  String o="";
    
   char oct[]={'0','1','2','3','4','5','6','7'};
   Scanner scan = new Scanner(System.in);
		
   System.out.print("Enter Binary Number : ");
   b = scan.nextInt();
	 
	while (b != 0) 
   {
   rem1= b % 10;
   Y = Y + rem1 * j;
   j = j * 2;
   b = b / 10;
   }	
   while(Y>0)
   {
   rem = Y%8;
    o = oct[rem] + o;
     Y= Y/8;
   }
		
   System.out.println("Octal value");
   System.out.print(o);
 }
}