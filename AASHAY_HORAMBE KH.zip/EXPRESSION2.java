public class EXPRESSION2
 {

    public static void main(String[] args)
   {
        
        int X,Y,Z,A;
        X=-5 +8 *6;
        Y=(55+9)% 9;
        Z=20 + (((-3)*5)/8);
        A=5 +((15/3) *2)-(8%3);
       System.out.println("OUTPUT OF FIRST EXPRESSION IS "+X);
       System.out.println("OUTPUT OF SECOND EXPRESSION IS "+Y);
       System.out.println("OUTPUT OF THIRD EXPRESSION IS "+Z);
       System.out.println("OUTPUT OF FOURTH EXPRESSION IS "+A);
    }
   
}
