import java.util.Scanner;
public class Swap
 {

    public static void main(String[] args)
   {
        
        int X,Y,Z ;
        System.out.println("Enter first number X=: ");
        Scanner sc1 = new Scanner(System.in);
        X=sc1.nextInt();
        System.out.println("Enter second number Y=: ");
        Scanner sc2 = new Scanner(System.in);
        Y=sc2.nextInt();  
        Z=X;
        X=Y;
        Y=Z;
        System.out.println("Swap values are X="+X+ " Y="+Y);
   }
}
