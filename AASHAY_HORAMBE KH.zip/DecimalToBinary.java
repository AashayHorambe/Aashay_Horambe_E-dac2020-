import java.util.Scanner;
public class DecimalToBinary
 {

    public static void main(String[] args)
   {
        
        int X,i=0,j ;
        int binary[]=new int[100];
        System.out.println("Enter number X=:");
        Scanner sc = new Scanner(System.in);
        X=sc.nextInt();
        while(X!=0)
        {
            binary[i]=X% 2;
            X=X/2;
            i++;
        }
       
        for(j=i-1;j>=0;j--)
        {
             System.out.print(binary[j]);
        }
    }

   
}
