
public class EXPRESSION
 {

    public static void main(String[] args)
   {
        
        float X=25.5f ,Y=3.5f ,Z=40.5f, A=4.5f;
        double B;
        B=(X*Y-Y*Y)/(Z-A);
       System.out.println("OUTPUT OF EXPRESSION is"+B);
    }
   
}
