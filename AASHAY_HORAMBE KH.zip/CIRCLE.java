public class CIRCLE
{
public static void main(String[] args)
{
double Rad=7.5;
double Per ,area;
	Per =2* (22/7)* Rad;
	area = (22/7)* Rad *Rad;
System.out.println("Perimeter of circle is" +Per);
System.out.println("area of circle is" +area);
}
}