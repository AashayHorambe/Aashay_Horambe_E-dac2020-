
class AddArray
{

public static void main(String args[])
{  
int even=0;
int odd=0;     
int [] a={2 ,5 ,8 ,6 ,3 ,5};
for(int i=0;i<a.length;i++)
{
if(a[i] %2==0)
{
even=even+a[i];
}
else
{
odd=odd+a[i];
}
}
System.out.println("Addition of even array "+even);   
System.out.println("Addition of even array "+odd);                                                                                                                                                                        
}
}