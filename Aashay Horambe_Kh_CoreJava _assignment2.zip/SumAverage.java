import java.util.Scanner;
class SumAverage
{

public static void main(String args[])
{ 
Scanner sc=new Scanner(System.in);
System.out.println("Enter number of array you want to print");
int n=sc.nextInt();
int a[]=new int[n];
int sum=0;
for(int i=0;i<n;i++)
{
int x=sc.nextInt();
a[i]=x;
}   
for(int j:a)
{
sum=sum+j;
}   
System.out.println("Sum of given array is "+sum);
System.out.print("Average of given array is "+((double)(sum/n)));
}
}                                                                                                                                                                   
