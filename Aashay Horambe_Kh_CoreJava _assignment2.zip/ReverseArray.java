class ReverseArray
{

public static void main(String args[])
{    
int [] a={2 ,5 ,8 ,6 ,3 ,5};

for(int i=(a.length)-1;i>=0;i--)
{
System.out.print(a[i]+" ");
}
}
}                                                                                                                                                                   

