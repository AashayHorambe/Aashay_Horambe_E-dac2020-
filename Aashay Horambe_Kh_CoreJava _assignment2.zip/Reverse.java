import java.util.Scanner;
class Reverse
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter a number for reverse");
int x=sc.nextInt();
int rem=0 ,rev=0;
while(x>0)
{
rem=x %10;
rev=(rev *10)+rem;
x=x/10;
}
System.out.println("Reverse number of given number is="+rev);
}
}