import java.util.Scanner;
class SearchElement
{

public static void main(String args[])
{     
int [] a={2 ,5 ,8 ,6 ,3 ,5};
Scanner sc=new Scanner(System.in);
System.out.println("Enter a number to search this array");
int b=sc.nextInt();
boolean flag=false;
for(int i=0;i<a.length;i++)
{
if(b==a[i])
{
flag=true;
}
}
if(flag==true)
{
System.out.println("This number present is this array");
}
else
{
System.out.println("This number not present is this array");
}
}
}                                                                                                                                                                   

