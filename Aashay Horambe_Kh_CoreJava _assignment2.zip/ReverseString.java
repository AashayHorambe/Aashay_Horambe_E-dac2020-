import java.util.*;
class ReverseString
{

public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter a string");       
String x=sc.nextLine();
String s="";
for(int i=0;i<x.length();i++)
{
s=x.charAt(i)+s;

}
System.out.println("Reverse String    "+s);                                                                                                                                                                        
}
}