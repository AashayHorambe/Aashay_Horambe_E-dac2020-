import java.util.Arrays;
class ReverseSort
{

public static void main(String args[])
{  
int even=0;
int odd=0;     
int [] a={2,5,8,6,3,5,6,1,5,3};
Arrays.sort(a);
//int c[]=new int[b.length];
for(int i=(a.length)-1;i>=0;i--)
{
System.out.print(a[i]+" ");
}
}
}                                                                                                                                                                   
