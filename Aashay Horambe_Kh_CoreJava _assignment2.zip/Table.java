import java.util.Scanner;
class Table
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter a number for table");
int x=sc.nextInt();
int mul;
for(int i=1;i<=10;i++)
{
 mul= i *x;
System.out.println(i+" * "+x+" = "+mul);
}
}
}