import java.util.Scanner;
class Series
{
public static void main(String args [])
{
int sum=0;
System.out.println("Enter a number to print 12+22+32+42....addition of this series");
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
{
for(int i=10;i<=n*10;i+=10)
{
int k=i+2;
sum=sum+k;

}
System.out.println("Sum of above series is: "+sum);
}
}
}