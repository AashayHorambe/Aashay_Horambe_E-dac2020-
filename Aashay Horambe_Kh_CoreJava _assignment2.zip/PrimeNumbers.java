import java.util.Scanner;
public class PrimeNumbers {

    public static void main(String[] args) 
	{
      System.out.print("Enter a number you want to print prime numbers ");
        int a =1;
  Scanner sc=new Scanner(System.in);
      int b=sc.nextInt();
        while (a< b) 
	{
            boolean flag = false;

            for(int i = 2; i <= a/2; ++i) {
                if(a % i == 0) {
                    flag = true;
                    break;
                }
            }

            if (!flag && a != 0 && a != 1)
                System.out.print(a + " ");

            ++a;
        }
    }
}